local UnitFrames = LibStub("AceAddon-3.0"):GetAddon("oUF_Real")
local Auras = UnitFrames.Auras
local db

local oUF = oUFembed

local _
local min = math.min
local max = math.max
local floor = _G.floor
local ceil = _G.ceil
local format = _G.format
local strform = _G.string.format
local tonumber = _G.tonumber
local tostring = _G.tostring
local strlen = _G.strlen
local strsub = _G.strsub

--------------------
------ Layout ------
--------------------

-- Unit Frames Sizes
local unit_sizes = {
	[1] = {
		player = 		{width = 224, height = 22},
		pet = 			{width = 10,  height = 22},
		pet2 = 			{width = 139, height = 22},
		focus = 		{width = 158, height = 10},
		focustarget = 	{width = 148, height = 10},
		target = 		{width = 224, height = 22},
		targettarget = 	{width = 158, height = 10},
		tank = 			{width = 158, height = 10},
		boss = 			{width = 135, height = 24},
	},
	[2] = {
		player = 		{width = 244, height = 22},
		pet = 			{width = 11,  height = 22},
		pet2 = 			{width = 139, height = 22},
		focus = 		{width = 168, height = 10},
		focustarget = 	{width = 158, height = 10},
		target = 		{width = 244, height = 22},
		targettarget = 	{width = 168, height = 10},
		tank = 			{width = 168, height = 10},
		boss = 			{width = 135, height = 24},
	},
}

-- Mouse Event
local OnEnter = function(self)
	UnitFrame_OnEnter(self)
end

local OnLeave = function(self)
	UnitFrame_OnLeave(self)
end

-- Dropdown Menu
local dropdown = CreateFrame("Frame", "RealUIUnitFramesDropDown", UIParent, "UIDropDownMenuTemplate")

hooksecurefunc("UnitPopup_OnClick",function(self)
	local button = self.value
	if button == "SET_FOCUS" or button == "CLEAR_FOCUS" then
		if StaticPopup1 then
			StaticPopup1:Hide()
		end
		if db.misc.focusclick then
			print("Use |cff0050ff"..db.misc.focuskey.."+click|r to set Focus.")
		end
	elseif button == "PET_DISMISS" then
		if StaticPopup1 then
			StaticPopup1:Hide()
		end
	end
end)

local function menu(self)
	dropdown:SetParent(self)
	return ToggleDropDownMenu(1, nil, dropdown, "cursor", 0, 0)
end

local init = function(self)
	local unit = self:GetParent().unit
	local menu, name, id
	
	if (not unit) then
		return
	end
	
	if (UnitIsUnit(unit, "player")) then
		menu = "SELF"
	elseif (UnitIsUnit(unit, "vehicle")) then
		menu = "VEHICLE"
	elseif (UnitIsUnit(unit, "pet")) then
		menu = "PET"
	elseif (UnitIsPlayer(unit)) then
		id = UnitInRaid(unit)
		if(id) then
			menu = "RAID_PLAYER"
			name = GetRaidRosterInfo(id)
		elseif(UnitInParty(unit)) then
			menu = "PARTY"
		else
			menu = "PLAYER"
		end
	else
		menu = "TARGET"
		name = RAID_TARGET_ICON
	end
	
	if (menu) then
		UnitPopup_ShowMenu(self, menu, unit, name, id)
	end
end

UIDropDownMenu_Initialize(dropdown, init, "MENU")

-- Frames
local function CreateInnerBD(parent)
	local bg = CreateFrame("Frame", nil, parent)
		bg:SetPoint("TOPLEFT", parent, 1, -1)
		bg:SetPoint("BOTTOMRIGHT", parent, -1, 1)

		bg:SetBackdrop({
			bgFile = [[Interface\AddOns\oUF_Real\media\plain]], 
			edgeFile =[[Interface\AddOns\oUF_Real\media\plain]], 
			edgeSize = 1,
		})
		bg:SetBackdropColor(0, 0, 0, 0)
		bg:SetBackdropBorderColor(0.2, 0.2, 0.2, db.overlay.bar.opacity.surround)
	return bg
end

local function CreateBD(parent, alpha)
	local bg = CreateFrame("Frame", nil, parent)
		bg:SetFrameStrata("LOW")
		bg:SetFrameLevel(parent:GetFrameLevel() - 1)
		bg:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", 1, -1)
		bg:SetPoint("TOPLEFT", parent, "TOPLEFT", -1, 1)
		bg:SetBackdrop({bgFile =[[Interface\AddOns\oUF_Real\media\plain]], edgeFile =[[Interface\AddOns\oUF_Real\media\plain]], edgeSize = 1, insets = {top = 0, bottom = 0, left = 0, right = 0}})
		bg:SetBackdropColor(0, 0, 0, alpha or db.overlay.bar.opacity.background)
		bg:SetBackdropBorderColor(0, 0, 0, db.overlay.bar.opacity.surround)
	return bg
end

local function Shared(self, unit)
	unit = unit:match("(boss)%d?$") or unit
	
	self.menu = menu
	
	self:SetScript("OnEnter", OnEnter)
	self:SetScript("OnLeave", OnLeave)
	self:RegisterForClicks"AnyUp"
	
  	if db.misc.focusclick then
		local ModKey = db.misc.focuskey
		local MouseButton = 1
		local key = ModKey .. "-type" .. (MouseButton or "")
		if(self.unit == "focus") then
			self:SetAttribute(key, "macro")
			self:SetAttribute("macrotext", "/clearfocus")
		else
			self:SetAttribute(key, "focus")
		end
	end
	
	-- Pet Major
	if UnitFrames.petFrameClass and (unit == "pet") then
		local font = {[[Interface\AddOns\oUF_Real\media\pixel_lr_small.ttf]], 8, "OUTLINEMONOCHROME"}

		local frameBD = CreateBD(self, 0)
			frameBD:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", 0, 0)
			frameBD:SetPoint("TOPLEFT", self, "TOPLEFT", 0, 0)
			oUF_RealPet_Overlay = frameBD

		local innerBD = CreateInnerBD(oUF_RealPet_Overlay)

		-- Health
		local Health = CreateFrame("StatusBar", nil, oUF_RealPet_Overlay)
		self.Health = Health
			Health:SetPoint("TOPRIGHT", oUF_RealPet_Overlay, "TOPRIGHT", -3, -3)
			Health:SetPoint("BOTTOMLEFT", oUF_RealPet_Overlay, "BOTTOMLEFT",	3, 6)
			Health:SetFrameLevel(oUF_RealPet_Overlay:GetFrameLevel() + 1)
			Health:SetStatusBarTexture([[Interface\AddOns\oUF_Real\media\plain]])
			Health:SetStatusBarColor(db.overlay.colors.health.hostile[1], db.overlay.colors.health.hostile[2], db.overlay.colors.health.hostile[3], db.overlay.bar.opacity.bar[2])
			Health:SetReverseFill(true)
			if db.pet.reverseHealth then
				Health.PostUpdate = function(Health, unit, min, max)
					Health:SetValue(max - Health:GetValue())
				end
			end
		local healthBG = CreateBD(Health)
		
		-- Power	
		local Power = CreateFrame("StatusBar", nil, oUF_RealPet_Overlay)
		self.Power = Power
			Power:SetPoint("BOTTOMRIGHT", oUF_RealPet_Overlay, "BOTTOMRIGHT", -3, 3)
			Power:SetPoint("TOPLEFT", oUF_RealPet_Overlay, "BOTTOMLEFT", 3, 5)
			Power:SetFrameLevel(oUF_RealPet_Overlay:GetFrameLevel() + 1)
			Power:SetStatusBarTexture([[Interface\AddOns\oUF_Real\media\plain]])
			Power:SetStatusBarColor(db.overlay.colors.power["MANA"][1], db.overlay.colors.power["MANA"][2], db.overlay.colors.power["MANA"][3], db.overlay.bar.opacity.bar[2])
			Power.colorPower = true
			Power.frequentUpdates = true
		local powerBG = CreateBD(Power, db.overlay.bar.opacity.bar[2] + 0.1)

		-- Text
		local HealthValue = Health:CreateFontString(nil, "OVERLAY")
		self.HealthValue = HealthValue
			HealthValue:SetPoint("BOTTOMRIGHT", Health, "BOTTOMRIGHT", 0.5, 1.5)
			HealthValue:SetFont(unpack(font))
			HealthValue:SetJustifyH("RIGHT")
		self:Tag(self.HealthValue, "[real:healthPercent]")
		
		local Name = Health:CreateFontString(nil, "OVERLAY")
		self.Name = Name
			Name:SetPoint("BOTTOMLEFT", Health, "BOTTOMLEFT", 1.5, 1.5)
			Name:SetFont(unpack(font))
			Name:SetJustifyH("LEFT")
		if db.pet.showName then
			self:Tag(self.Name, "[real:name]")
		end

		-- Cast Bar
		local castTop = CreateFrame("StatusBar", nil, oUF_RealPet_Overlay)
			castTop:Hide()
			castTop:SetPoint("TOPLEFT", oUF_RealPet_Overlay, "TOPLEFT", 1, -1)
			castTop:SetPoint("BOTTOMRIGHT", oUF_RealPet_Overlay, "TOPRIGHT", -1, -2)
			castTop:SetStatusBarTexture([[Interface\AddOns\oUF_Real\media\plain]])
			castTop:SetStatusBarColor(db.pet.castBarColor[1], db.pet.castBarColor[2], db.pet.castBarColor[3], db.overlay.bar.opacity.bar[2])

		local castBottom = CreateFrame("StatusBar", nil, oUF_RealPet_Overlay)
			castBottom:Hide()
			castBottom:SetPoint("BOTTOMLEFT", oUF_RealPet_Overlay, "BOTTOMLEFT", 1, 1)
			castBottom:SetPoint("TOPRIGHT", oUF_RealPet_Overlay, "BOTTOMRIGHT", -1, 2)
			castBottom:SetStatusBarTexture([[Interface\AddOns\oUF_Real\media\plain]])
			castBottom:SetStatusBarColor(db.pet.castBarColor[1], db.pet.castBarColor[2], db.pet.castBarColor[3], db.overlay.bar.opacity.bar[2])

		local castStart = innerBD:CreateTexture("ARTWORK")
			castStart:Hide()
			castStart:SetTexture(db.pet.castBarColor[1], db.pet.castBarColor[2], db.pet.castBarColor[3], db.overlay.bar.opacity.bar[2])
			castStart:SetPoint("BOTTOMLEFT", oUF_RealPet_Overlay, "BOTTOMLEFT", 1, 2)
			castStart:SetPoint("TOPRIGHT", oUF_RealPet_Overlay, "TOPLEFT", 2, -2)

		local castEnd = innerBD:CreateTexture("ARTWORK")
			castEnd:Hide()
			castEnd:SetTexture(db.pet.castBarColor[1], db.pet.castBarColor[2], db.pet.castBarColor[3], db.overlay.bar.opacity.bar[2])
			castEnd:SetPoint("BOTTOMRIGHT", oUF_RealPet_Overlay, "BOTTOMRIGHT", -1, 2)
			castEnd:SetPoint("TOPLEFT", oUF_RealPet_Overlay, "TOPRIGHT", -2, -2)

		local castIconBG = CreateBD(castTop)
			castIconBG:ClearAllPoints()
			castIconBG:SetWidth(unit_sizes[db.layout].pet2.height)
			castIconBG:SetHeight(unit_sizes[db.layout].pet2.height)
			castIconBG:SetPoint("BOTTOMRIGHT", oUF_RealPet_Overlay, "BOTTOMLEFT", -1, 0)

		local castIcon = castIconBG:CreateTexture("ARTWORK")
			castIcon:SetWidth(unit_sizes[db.layout].pet2.height - 2)
			castIcon:SetHeight(unit_sizes[db.layout].pet2.height - 2)
			castIcon:SetPoint("BOTTOMRIGHT", castIconBG, "BOTTOMRIGHT", -1, 1)
			castIcon:SetTexCoord(0.1, 0.9, 0.1, 0.9)

		local castText = castIconBG:CreateFontString(nil, "OVERLAY")
			castText:SetPoint("BOTTOMLEFT", Health, "BOTTOMLEFT", 1.5, 1.5)
			castText:SetFont(unpack(font))
			castText:SetJustifyH("LEFT")

		local castTime = castIconBG:CreateFontString(nil, "OVERLAY")
			castTime:SetPoint("BOTTOMRIGHT", Health, "BOTTOMRIGHT", 0.5, 1.5)
			castTime:SetFont(unpack(font))
			castTime:SetJustifyH("RIGHT")

		local Castbar = castTop
		self.Castbar = Castbar
			Castbar.Text = castText
			Castbar.Time = castTime
			Castbar.bg = castIconBG
			Castbar.Icon = castIcon
			Castbar.CustomTimeText = function(self, duration)
				if(self.channeling) then
					self.Time:SetFormattedText('%.1f ', duration)
				elseif(self.casting) then
					self.Time:SetFormattedText('%.1f ', self.max - duration)
				end
			end

		Castbar:HookScript("OnShow", function()
			Name:Hide()
			HealthValue:Hide()
			Portrait:Hide()
			castStart:Show()
			castBottom:Show()
			castBottom:SetMinMaxValues(Castbar:GetMinMaxValues())
		end)
		Castbar:HookScript("OnHide", function()
			Name:Show()
			HealthValue:Show()
			Portrait:Show()
			castStart:Hide()
			castBottom:Hide()
		end)
		Castbar:HookScript("OnValueChanged", function(self, value)
			castBottom:SetValue(value)
		end)

		local PetBuffs = CreateFrame("Frame", nil, self)
		self.Buffs = PetBuffs
			PetBuffs:SetPoint("BOTTOMLEFT", self, "BOTTOMRIGHT", 1, 0)
			PetBuffs:SetWidth(88)
			PetBuffs:SetHeight(unit_sizes[db.layout].pet2.height)
			PetBuffs["size"] = unit_sizes[db.layout].pet2.height
			PetBuffs["spacing"] = 1
			PetBuffs["num"] = 3
			PetBuffs["growth-x"] = "RIGHT"
			PetBuffs.disableCooldown = true
			PetBuffs.PostUpdateIcon = Auras.PostUpdateIcon
			PetBuffs.PreSetPosition = Auras.PreSetPosition
			PetBuffs.CustomFilter = Auras.FilterPetBuffs


	-- Boss Frames
	elseif (unit == "boss") then
		local font = {[[Interface\AddOns\oUF_Real\media\pixel_lr_small.ttf]], 8, "OUTLINEMONOCHROME"}

		local Health = CreateFrame("StatusBar", nil, self)
		self.Health = Health
			Health:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 0, 1)
			Health:SetPoint("TOPRIGHT", self, "TOPRIGHT", 0, -1)
			Health:SetStatusBarTexture([[Interface\AddOns\oUF_Real\media\plain]])
			Health:SetStatusBarColor(db.overlay.colors.health.hostile[1], db.overlay.colors.health.hostile[2], db.overlay.colors.health.hostile[3], db.overlay.bar.opacity.bar[2])
			Health.frequentUpdates = true
			if db.boss.reverseHealth then
				Health:SetReverseFill(true)
				Health.PostUpdate = function(Health, unit, min, max)
					Health:SetValue(max - Health:GetValue())
				end
			end
		
		local healthBG = CreateBD(Health, 0.5)
			healthBG:SetFrameStrata("LOW")
			
		local HealthValue = Health:CreateFontString(nil, "OVERLAY")
		self.HealthValue = HealthValue
			HealthValue:SetPoint("TOPLEFT", Health, "TOPLEFT", 2.5, -6.5)
			HealthValue:SetFont(unpack(font))
			HealthValue:SetJustifyH("LEFT")
		self:Tag(self.HealthValue, "[real:healthPercent]")
		
		local Name = Health:CreateFontString(nil, "OVERLAY")
		self.Name = Name
			Name:SetPoint("TOPRIGHT", Health, "TOPRIGHT", -0.5, -6.5)
			Name:SetFont(unpack(font))
			Name:SetJustifyH("RIGHT")
		self:Tag(self.Name, "[real:name]")
			
		local Power = CreateFrame("StatusBar", nil, self)
			self.Power = Power
			Power:SetFrameStrata("MEDIUM")
			Power:SetFrameLevel(6)
			Power:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", 0, 1)
			Power:SetPoint("TOPLEFT", self, "BOTTOMLEFT", 0, 3)
			Power:SetStatusBarTexture([[Interface\AddOns\oUF_Real\media\plain]])
			Power:SetStatusBarColor(db.overlay.colors.power["MANA"][1], db.overlay.colors.power["MANA"][2], db.overlay.colors.power["MANA"][3], db.overlay.bar.opacity.bar[2])
			Power.colorPower = true
			Power.PostUpdate = function(bar, unit, min, max)
				bar:SetShown(max > 0)
			end
		
		local powerBG = CreateBD(Power, 0.5)
			powerBG:SetFrameStrata("LOW")
			
		-- local AltPowerBar = CreateFrame("StatusBar", nil, self)
		-- self.AltPowerBar = AltPowerBar
		-- 	AltPowerBar:SetFrameStrata("MEDIUM")
		-- 	AltPowerBar:SetFrameLevel(6)
		-- 	AltPowerBar:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", -97, 2 + bossFrameSizes[db.boss.size].power.y)
		-- 	AltPowerBar:SetPoint("BOTTOMLEFT", self, "BOTTOMLEFT", 5, 2 + bossFrameSizes[db.boss.size].power.y)
		-- 	AltPowerBar:SetPoint("TOP", Health, "BOTTOM", 0, -5 + bossFrameSizes[db.boss.size].power.height + bossFrameSizes[db.boss.size].power.y)
		-- 	AltPowerBar:SetStatusBarTexture([[Interface\AddOns\oUF_Real\media\plain]])
		-- 	-- AltPowerBar:SetStatusBarColor(db.overlay.colors.power["ALTERNATE"][1], db.overlay.colors.power["ALTERNATE"][2], db.overlay.colors.power["ALTERNATE"][3], db.overlay.bar.opacity.bar[2])
		-- 	AltPowerBar.colorPower = true

		-- local altpowerBG = CreateBD(AltPowerBar)
		-- 	altpowerBG:SetFrameStrata("MEDIUM")
		-- 	altpowerBG:SetFrameLevel(5)
		
		local BossAuras = CreateFrame("Frame", nil, self)
		self.Auras = BossAuras
			BossAuras:SetPoint("BOTTOMRIGHT", self, "BOTTOMLEFT", unit_sizes[db.layout].boss.height * ((db.boss.buffCount + db.boss.debuffCount) - 1) + 6, 0)
			BossAuras:SetWidth((unit_sizes[db.layout].boss.height + 1) * (db.boss.buffCount + db.boss.debuffCount))
			BossAuras:SetHeight(unit_sizes[db.layout].boss.height)
			BossAuras["size"] = unit_sizes[db.layout].boss.height
			BossAuras["spacing"] = 1
			BossAuras["numBuffs"] = db.boss.buffCount
			BossAuras["numDebuffs"] = db.boss.debuffCount
			BossAuras["growth-x"] = "LEFT"
			BossAuras.disableCooldown = true
			BossAuras.CustomFilter = Auras.FilterBossAuras
			BossAuras.PostUpdateIcon = Auras.PostUpdateIcon
			-- BossAuras.showType = true
			-- BossAuras.showStealableAuras = true

		local RaidIcon = self:CreateTexture(nil, 'OVERLAY')
		self.RaidIcon = RaidIcon
			RaidIcon:SetSize(unit_sizes[db.layout].boss.height - 1, unit_sizes[db.layout].boss.height - 1)
			RaidIcon:SetPoint("LEFT", self, "RIGHT", 1, 1)
	end
end

function UnitFrames:InitializeLayout()
	db = self.db.profile
	oUF:RegisterStyle("RealUI", Shared)
	
	local UnitSpecific = {
		player = function(self, ...)
			Shared(self, ...)
			self:SetSize(unit_sizes[db.layout].player.width, unit_sizes[db.layout].player.height)
		end,
		
		focus = function(self, ...)
			Shared(self, ...)
			self:SetSize(unit_sizes[db.layout].focus.width, unit_sizes[db.layout].focus.height)
		end,
		
		focustarget = function(self, ...)
			Shared(self, ...)
			self:SetSize(unit_sizes[db.layout].focustarget.width, unit_sizes[db.layout].focustarget.height)
		end,
		
		pet = function(self, ...)
			Shared(self, ...)
			if not(UnitFrames.petFrameClass) then
				self:SetSize(unit_sizes[db.layout].pet.width, unit_sizes[db.layout].pet.height)
			else
				self:SetSize(unit_sizes[db.layout].pet2.width, unit_sizes[db.layout].pet2.height)
			end
		end,

		target = function(self, ...)
			Shared(self, ...)
			self:SetSize(unit_sizes[db.layout].target.width, unit_sizes[db.layout].target.height)
		end,
		
		targettarget = function(self, ...)
			Shared(self, ...)
			self:SetSize(unit_sizes[db.layout].targettarget.width, unit_sizes[db.layout].targettarget.height)
		end,
		
		boss = function(self, ...)
			Shared(self, ...)
			self:SetSize(unit_sizes[db.layout].boss.width, unit_sizes[db.layout].boss.height)
		end
	}

	for unit,layout in next, UnitSpecific do
		oUF:RegisterStyle("Real - " .. unit:gsub("^%l", string.upper), layout)
	end

	local function spawnHelper(self, unit, ...)
		if (UnitSpecific[unit]) then
			self:SetActiveStyle("Real - " .. unit:gsub("^%l", string.upper))
		elseif(UnitSpecific[unit:match("[^%d]+")]) then 
			self:SetActiveStyle("Real - " .. unit:match("[^%d]+"):gsub("^%l", string.upper))
		else
			self:SetActiveStyle("Real")
		end
		
		local object = self:Spawn(unit)
		object:SetPoint(...)
		return object
	end

	oUF:Factory(function(self)
		spawnHelper(self, "player", 		"CENTER", "UIParent", "CENTER",	db.positions[db.layout].player.x, 		db.positions[db.layout].player.y)
		spawnHelper(self, "focus", 			"RIGHT", "oUF_RealPlayer", 		db.positions[db.layout].focus.x, 		db.positions[db.layout].focus.y)
		spawnHelper(self, "focustarget", 	"RIGHT", "oUF_RealFocus", 		db.positions[db.layout].focustarget.x, 	db.positions[db.layout].focustarget.y)
		spawnHelper(self, "target", 		"CENTER", "UIParent", "CENTER",	db.positions[db.layout].target.x, 		db.positions[db.layout].target.y)
		spawnHelper(self, "targettarget", 	"LEFT", "oUF_RealTarget", 		db.positions[db.layout].targettarget.x, db.positions[db.layout].targettarget.y)
		
		if not(UnitFrames.petFrameClass) then
			spawnHelper(self, "pet", "RIGHT", "oUF_RealPlayer", db.positions[db.layout].pet.x, db.positions[db.layout].pet.y)
		else
			spawnHelper(self, "pet", "CENTER", "UIParent", db.positions[db.layout].pet2.x, db.positions[db.layout].pet2.y)
		end

		for b = 1, MAX_BOSS_FRAMES do
			local boss = spawnHelper(self, "boss"..b, "RIGHT", "UIParent", "RIGHT", db.positions[db.layout].boss.x, db.positions[db.layout].boss.y)
			if (b ~= 1) then
				boss:SetPoint("TOP", _G["oUF_RealBoss" .. b - 1], "BOTTOM", 0, -db.boss.gap)
			end

			local blizzBF = _G["Boss" .. b .. "TargetFrame"]
			blizzBF:UnregisterAllEvents()
			blizzBF:Hide()
		end
	end)

	self:InitializeOverlay()
end

function RealUIUFBossConfig(toggle, unit)
	for b = 1, MAX_BOSS_FRAMES do
		local f = _G["oUF_RealBoss" .. b]
		if toggle then
			if not f.__realunit then
				f.__realunit = f:GetAttribute("unit") or f.unit
				f:SetAttribute("unit", unit)
				f.unit = unit
				f:Show()
			end
		else
			if f.__realunit then
				f:SetAttribute("unit", f.__realunit)
				f.unit = f.__realunit
				f.__realunit = nil
				f:Hide()
			end
		end
	end
end