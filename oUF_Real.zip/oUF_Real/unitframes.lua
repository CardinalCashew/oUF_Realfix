local UnitFrames = LibStub("AceAddon-3.0"):NewAddon("oUF_Real", "AceConsole-3.0", "AceEvent-3.0")
local db

local oUF = oUFembed

local _
local min = math.min
local max = math.max
local floor = _G.floor
local ceil = _G.ceil
local format = _G.format
local strform = _G.string.format
local tonumber = _G.tonumber
local tostring = _G.tostring
local strlen = _G.strlen
local strsub = _G.strsub

local PLAYER_ID = "player"
local PET_ID = "pet"
local VEHICLE_ID = "vehicle"
local FOCUS_ID = "focus"
local FOCUSTARGET_ID = "focustarget"
local TARGET_ID = "target"
local TARGETTARGET_ID = "targettarget"
local MAINTANK_ID = "maintank"
local BOSS_ID = "boss"

local fonts = {
	[1] = {[[Interface\AddOns\oUF_Real\media\pixel_lr_small.ttf]], 8, "OUTLINEMONOCHROME"},
	[2] = {[[Interface\AddOns\oUF_Real\media\pixel_hr_small.ttf]], 8, "OUTLINEMONOCHROME"}
}

---------------------
------ Options ------
---------------------
local function ValidateOffset(value, ...)
	local val = tonumber(value)
	local vmin, vmax = -5000, 5000
	if ... then vmin, vmax = ... end	
	if val == nil then val = 0 end
	val = max(val, vmin)
	val = min(val, vmax)
	return val
end

local Layouts = {
	"small",
	"large"
}
local ModKeys = {
	"shift",
	"ctrl",
	"alt"
}
local BossSizes = {
	"tiny",
	"small",
	"medium",
	"large",
	"super"
}
local options
local function GetOptions()
	if not options then options = {
		type = "group",
		name = "|cffbf3030oUF|r|cffa0a0a0_|r|cffffffffReal|r",
		childGroups = "tab",
		args = {
			desc1 = {
				type = "description",
				name = "Note: You will need to reload the UI (/rl) for changes to take effect.",
				order = 1,
			},
			gap1 = {
				name = " ",
				type = "description",
				order = 2,
			},
			layout = {
				type = "select",
				name = "Layout",
				set = function(info, value)
					db.layout = value
					UnitFrames:CloseOptions()
					UnitFrames:ReloadUIDialog()
				end,
				style = "dropdown",
				width = nil,
				values = Layouts,
				order = 10,
			},
			layoutname = {
				name = function()
					return "  "..Layouts[db.layout]
				end,
				type = "description",
				order = 11,
			},
			gap2 = {
				name = " ",
				type = "description",
				order = 12,
			},
			misc = {
				type = "group",
				name = "General",
				order = 30,
				args = {
					focusclick = {
						type = "toggle",
						name = "Click Set Focus",
						desc = "Set focus by click+modifier on the Unit Frames.",
						get = function() return db.misc.focusclick end,
						set = function(info, value) 
							db.misc.focusclick = value
						end,
						order = 10,
					},
					gap1 = {
						name = " ",
						type = "description",
						order = 11,
					},
					focuskey = {
						type = "select",
						name = "Modifier Key",
						set = function(info, value)
							db.misc.focuskey = ModKeys[value]
						end,
						style = "dropdown",
						width = nil,
						values = ModKeys,
						order = 20,
					},
					focuskeyname = {
						name = function()
							return "  "..db.misc.focuskey
						end,
						type = "description",
						order = 21,
					},
				},
			},
			pet = {
				type = "group",
				name = "Pet Frame",
				order = 40,
				args = {
					classes = {
						type = "group",
						inline = true,
						name = "Classes",
						order = 10,
						args = {
							deathknight = {
								type = "toggle",
								name = "DEATHKNIGHT",
								get = function() return UnitFrames.db.profile.petFrameClasses["DEATHKNIGHT"] end,
								set = function(info, value)
									UnitFrames.db.profile.petFrameClasses["DEATHKNIGHT"] = value
								end,
								order = 10,
							},
							hunter = {
								type = "toggle",
								name = "HUNTER",
								get = function() return UnitFrames.db.profile.petFrameClasses["HUNTER"] end,
								set = function(info, value)
									UnitFrames.db.profile.petFrameClasses["HUNTER"] = value
								end,
								order = 20,
							},
							mage = {
								type = "toggle",
								name = "MAGE",
								get = function() return UnitFrames.db.profile.petFrameClasses["MAGE"] end,
								set = function(info, value)
									UnitFrames.db.profile.petFrameClasses["MAGE"] = value
								end,
								order = 30,
							},
							warlock = {
								type = "toggle",
								name = "WARLOCK",
								get = function() return UnitFrames.db.profile.petFrameClasses["WARLOCK"] end,
								set = function(info, value)
									UnitFrames.db.profile.petFrameClasses["WARLOCK"] = value
								end,
								order = 40,
							},
						},
					},
					showName = {
						type = "toggle",
						name = "Show Pet Name",
						get = function() return db.pet.showName end,
						set = function(info, value) 
							db.pet.showName = value
						end,
						order = 20,
					},
					-- hideOOC = {
					-- 	type = "toggle",
					-- 	name = "Hide OOC",
					-- 	desc = "Hide Pet Frame when out of combat.",
					-- 	get = function() return db.pet.hideOOC end,
					-- 	set = function(info, value) 
					-- 		db.pet.hideOOC = value
					-- 	end,
					-- 	order = 30,
					-- },
					reverseHealth = {
						type = "toggle",
						name = "Reverse fill Health",
						get = function() return db.pet.reverseHealth end,
						set = function(info, value) 
							db.pet.reverseHealth = value
						end,
						order = 40,
					},
					castBarColor = {
						type = "color",
						name = "Cast Bar",
						get = function(info,r,g,b)
							return db.pet.castBarColor[1], db.pet.castBarColor[2], db.pet.castBarColor[3]
						end,
						set = function(info,r,g,b)
							db.pet.castBarColor[1] = r
							db.pet.castBarColor[2] = g
							db.pet.castBarColor[3] = b
						end,
						order = 50,
					},
				},
			},
			boss = {
				type = "group",
				name = "Boss Frames",
				order = 50,
				args = {
					gap1 = {
						name = " ",
						type = "description",
						order = 12,
					},
					gap = {
						type = "range",
						name = "Gap",
						desc = "Vertical distance between each Boss Frame.",
						min = 0, max = 10, step = 1,
						get = function(info) return db.boss.gap end,
						set = function(info, value) db.boss.gap = value end,
						order = 20,
					},
					gap2 = {
						name = " ",
						type = "description",
						order = 21,
					},
					reverseHealth = {
						type = "toggle",
						name = "Reverse Health Bar",
						get = function() return db.boss.reverseHealth end,
						set = function(info, value) 
							db.boss.reverseHealth = value
						end,
						order = 30,
					},
					gap3 = {
						name = " ",
						type = "description",
						order = 41,
					},
					auras = {
						type = "group",
						inline = true,
						name = "Auras",
						order = 50,
						args = {
							showPlayerAuras = {
								type = "toggle",
								name = "Show Player Auras",
								desc = "Show Buffs/Debuffs cast by you.",
								get = function() return db.boss.showPlayerAuras end,
								set = function(info, value) 
									db.boss.showPlayerAuras = value
								end,
								order = 10,
							},
							showNPCAuras = {
								type = "toggle",
								name = "Show NPC Auras",
								desc = "Show Buffs/Debuffs cast by NPCs.",
								get = function() return db.boss.showNPCAuras end,
								set = function(info, value) 
									db.boss.showNPCAuras = value
								end,
								order = 20,
							},
							buffCount = {
								type = "range",
								name = "Buff Count",
								min = 1, max = 8, step = 1,
								get = function(info) return db.boss.buffCount end,
								set = function(info, value) db.boss.buffCount = value end,
								order = 30,
							},
							debuffCount = {
								type = "range",
								name = "Debuff Count",
								min = 1, max = 8, step = 1,
								get = function(info) return db.boss.debuffCount end,
								set = function(info, value) db.boss.debuffCount = value end,
								order = 40,
							},
						},
					},
				},
			},
			positions = {
				type = "group",
				name = "Positions",
				order = 60,
				args = {},
			},
			overlay = {
				type = "group",
				name = "Appearance",
				childGroups = "tab",
				order = 70,
				args = {
					bar = {
						type = "group",
						name = "Bars",
						order = 10,
						args = {
							colors = {
								type = "group",
								inline = true,
								name = "Color Type",
								order = 10,
								args = {
									byhostility = {
										type = "toggle",
										name = "Color by Hostility",
										desc = "Color Unit Frame bars based on the unit's hostility towards you.",
										get = function() return db.overlay.bar.colors.byhostility end,
										set = function(info, value) 
											db.overlay.bar.colors.byhostility = value
										end,
										order = 10,
									},
									byclass = {
										type = "toggle",
										name = "Color by Class",
										desc = "Color Unit Frame bars based on the unit's class.",
										get = function() return db.overlay.bar.colors.byclass end,
										set = function(info, value) 
											db.overlay.bar.colors.byclass = value
										end,
										order = 20,
									},
								},
							},
							opacity = {
								type = "group",
								inline = true,
								name = "Opacity",
								order = 20,
								args = {
									surround = {
										type = "range",
										name = "Surround",
										min = 0, max = 1, step = 0.05,
										isPercent = true,
										get = function(info) return db.overlay.bar.opacity.surround end,
										set = function(info, value) db.overlay.bar.opacity.surround = value end,
										order = 10,
									},
									background = {
										type = "range",
										name = "Background",
										min = 0, max = 1, step = 0.05,
										isPercent = true,
										get = function(info) return db.overlay.bar.opacity.background end,
										set = function(info, value) db.overlay.bar.opacity.background = value end,
										order = 20,
									},
									status = {
										type = "range",
										name = "Status",
										min = 0, max = 1, step = 0.05,
										isPercent = true,
										get = function(info) return db.overlay.bar.opacity.status end,
										set = function(info, value) db.overlay.bar.opacity.status = value end,
										order = 30,
									},
									steps = {
										type = "range",
										name = "Steps",
										min = 0, max = 1, step = 0.05,
										isPercent = true,
										get = function(info) return db.overlay.bar.opacity.steps end,
										set = function(info, value) db.overlay.bar.opacity.steps = value end,
										order = 40,
									},
									absorb = {
										type = "range",
										name = "Absorb Bar",
										min = 0, max = 1, step = 0.05,
										isPercent = true,
										get = function(info) return db.overlay.bar.opacity.absorb end,
										set = function(info, value) db.overlay.bar.opacity.absorb = value end,
										order = 50,
									},
									gap1 = {
										name = " ",
										type = "description",
										order = 51,
									},
									bar = {
										type = "group",
										inline = true,
										name = "Health/Power Bars",
										order = 60,
										args = {
											start = {
												type = "range",
												name = "Start",
												min = 0, max = 1, step = 0.05,
												isPercent = true,
												get = function(info) return db.overlay.bar.opacity.bar[1] end,
												set = function(info, value) db.overlay.bar.opacity.bar[1] = value end,
												order = 10,
											},
											finish = {
												type = "range",
												name = "End",
												min = 0, max = 1, step = 0.05,
												isPercent = true,
												get = function(info) return db.overlay.bar.opacity.bar[2] end,
												set = function(info, value) db.overlay.bar.opacity.bar[2] = value end,
												order = 20,
											},
										},
									},
									gap2 = {
										name = " ",
										type = "description",
										order = 61,
									},
									bar2 = {
										type = "group",
										inline = true,
										name = "Pet/Vehicle/Druid Mana Bars",
										order = 70,
										args = {
											start = {
												type = "range",
												name = "Start",
												min = 0, max = 1, step = 0.05,
												isPercent = true,
												get = function(info) return db.overlay.bar.opacity.bar2[1] end,
												set = function(info, value) db.overlay.bar.opacity.bar2[1] = value end,
												order = 10,
											},
											finish = {
												type = "range",
												name = "End",
												min = 0, max = 1, step = 0.05,
												isPercent = true,
												get = function(info) return db.overlay.bar.opacity.bar2[2] end,
												set = function(info, value) db.overlay.bar.opacity.bar2[2] = value end,
												order = 20,
											},
										},
									},
								},
							},
						},
					},
					arrow = {
						type = "group",
						name = "Arrows",
						order = 20,
						args = {
							opacity = {
								type = "group",
								inline = true,
								name = "Opacity",
								order = 10,
								args = {
									surround = {
										type = "range",
										name = "Surround",
										min = 0, max = 1, step = 0.05,
										isPercent = true,
										get = function(info) return db.overlay.arrow.opacity.surround end,
										set = function(info, value) db.overlay.arrow.opacity.surround = value end,
										order = 10,
									},
									background = {
										type = "range",
										name = "Background",
										min = 0, max = 1, step = 0.05,
										isPercent = true,
										get = function(info) return db.overlay.arrow.opacity.background end,
										set = function(info, value) db.overlay.arrow.opacity.background = value end,
										order = 20,
									},
								},
							},
							colors = {
								type = "group",
								inline = true,
								name = "Colors",
								order = 10,
								args = {
									step1 = {
										type = "color",
										name = "Full",
										get = function(info,r,g,b,a)
											return db.overlay.arrow.colors[1][1], db.overlay.arrow.colors[1][2], db.overlay.arrow.colors[1][3]
										end,
										set = function(info,r,g,b,a)
											db.overlay.arrow.colors[1][1] = r
											db.overlay.arrow.colors[1][2] = g
											db.overlay.arrow.colors[1][3] = b
										end,
										order = 10,
									},
									step2 = {
										type = "color",
										name = "Warning",
										get = function(info,r,g,b,a)
											return db.overlay.arrow.colors[2][1], db.overlay.arrow.colors[2][2], db.overlay.arrow.colors[2][3]
										end,
										set = function(info,r,g,b,a)
											db.overlay.arrow.colors[2][1] = r
											db.overlay.arrow.colors[2][2] = g
											db.overlay.arrow.colors[2][3] = b
										end,
										order = 20,
									},
									step3 = {
										type = "color",
										name = "Red Alert",
										get = function(info,r,g,b,a)
											return db.overlay.arrow.colors[3][1], db.overlay.arrow.colors[3][2], db.overlay.arrow.colors[3][3]
										end,
										set = function(info,r,g,b,a)
											db.overlay.arrow.colors[3][1] = r
											db.overlay.arrow.colors[3][2] = g
											db.overlay.arrow.colors[3][3] = b
										end,
										order = 30,
									},
									step4 = {
										type = "color",
										name = "Danger",
										get = function(info,r,g,b,a)
											return db.overlay.arrow.colors[4][1], db.overlay.arrow.colors[4][2], db.overlay.arrow.colors[4][3]
										end,
										set = function(info,r,g,b,a)
											db.overlay.arrow.colors[4][1] = r
											db.overlay.arrow.colors[4][2] = g
											db.overlay.arrow.colors[4][3] = b
										end,
										order = 40,
									},
								},
							},
						},
					},
					colors = {
						type = "group",
						name = "Colors",
						order = 30,
						args = {},
					},
				},
			},
			combatFader = {
				type = "group",
				name = "Combat Fader",
				order = 80,
				args = {
					incombat = {
						type = "range",
						name = "In-combat",
						min = 0, max = 1, step = 0.05,
						isPercent = true,
						get = function(info) return db.combatFader.opacity.incombat end,
						set = function(info, value)
							db.combatFader.opacity.incombat = value
						end,
						order = 10,
					},
					hurt = {
						type = "range",
						name = "Hurt",
						min = 0, max = 1, step = 0.05,
						isPercent = true,
						get = function(info) return db.combatFader.opacity.hurt end,
						set = function(info, value) 
							db.combatFader.opacity.hurt = value
						end,
						order = 20,
					},
					target = {
						type = "range",
						name = "Target-selected",
						min = 0, max = 1, step = 0.05,
						isPercent = true,
						get = function(info) return db.combatFader.opacity.target end,
						set = function(info, value)
							db.combatFader.opacity.target = value
						end,
						order = 30,
					},
					outofcombat = {
						type = "range",
						name = "Out-of-combat",
						min = 0, max = 1, step = 0.05,
						isPercent = true,
						get = function(info) return db.combatFader.opacity.outofcombat end,
						set = function(info, value)
							db.combatFader.opacity.outofcombat = value
						end,
						order = 40,
					},
				},
			},
		},
	}
	end
	
	---------------
	-- Positions --
	---------------
	local PositionLayoutOpts, PositionOpts = {}, {}
	local Opts_PositionOrderCnt = 10
	for kl,vl in pairs(db.positions) do
		local layout = kl == 1 and "Small" or "Large"
		wipe(PositionOpts)
		for ip,vp in pairs(db.positions[kl]) do
			PositionOpts[ip] = {
				type = "group",
				name = ip,
				order = Opts_PositionOrderCnt,
				args = {
					x = {
						type = "input",
						name = "X",
						width = "half",
						order = 10,
						get = function(info) return tostring(db.positions[kl][ip].x) end,
						set = function(info, value)
							value = ValidateOffset(value)
							db.positions[kl][ip].x = value
						end,
					},
					y = {
						type = "input",
						name = "Y",
						width = "half",
						order = 20,
						get = function(info) return tostring(db.positions[kl][ip].y) end,
						set = function(info, value)
							value = ValidateOffset(value)
							db.positions[kl][ip].y = value
						end,
					},
				},
			};
			
			Opts_PositionOrderCnt = Opts_PositionOrderCnt + 10
		end
		
		PositionLayoutOpts["res"..kl] = {
			type = "group",
			name = layout,
			order = kl,
			args = {}
		}
		for key, val in pairs(PositionOpts) do
			PositionLayoutOpts["res"..kl].args[key] = (type(val) == "function") and val() or val
		end
	end
	for key, val in pairs(PositionLayoutOpts) do
		options.args.positions.args[key] = (type(val) == "function") and val() or val
	end
	
	------------
	-- Colors --
	------------
	local ColorGroupOpts, ColorOpts = {}, {}
	local Opts_ColorGroupOrderCnt, Opts_ColorsOrderCnt = 10, 10
	for kl,vl in pairs(db.overlay.colors) do
		wipe(ColorOpts)
		for ic,vc in pairs(db.overlay.colors[kl]) do
			ColorOpts[ic] = {
				type = "color",
				name = ic,
				get = function(info,r,g,b,a)
					return db.overlay.colors[kl][ic][1], db.overlay.colors[kl][ic][2], db.overlay.colors[kl][ic][3]
				end,
				set = function(info,r,g,b,a)
					db.overlay.colors[kl][ic][1] = r
					db.overlay.colors[kl][ic][2] = g
					db.overlay.colors[kl][ic][3] = b
				end,
				order = 10,
			};
			
			Opts_ColorsOrderCnt = Opts_ColorsOrderCnt + 10
		end
		
		ColorGroupOpts[kl] = {
			type = "group",
			inline = true,
			name = kl,
			order = Opts_ColorGroupOrderCnt,
			args = {}
		}
		for key, val in pairs(ColorOpts) do
			ColorGroupOpts[kl].args[key] = (type(val) == "function") and val() or val
		end
		Opts_ColorGroupOrderCnt = Opts_ColorGroupOrderCnt + 10
	end
	for key, val in pairs(ColorGroupOpts) do
		options.args.overlay.args.colors.args[key] = (type(val) == "function") and val() or val
	end

	return options
end

function UnitFrames:ReloadUIDialog()
	LibStub("AceConfigDialog-3.0"):Close("oUF_Real")

	-- Display Dialog
	StaticPopupDialogs["PUDOUFREALRELOADUI"] = {
		text = "You need to Reload the UI for changes to take effect. Reload Now?",
		button1 = "Yes",
		button2 = "No",
		OnAccept = function()
			ReloadUI()
		end,
		timeout = 0,
		whileDead = true,
		hideOnEscape = true,
		notClosableByLogout = false,
	}
	StaticPopup_Show("PUDOUFREALRELOADUI")
end

-- Colors
function UnitFrames:ColorTableToStr(vals)
	return string.format("%02x%02x%02x", vals[1] * 255, vals[2] * 255, vals[3] * 255)
end

-- Backdrop frame
function UnitFrames:CreateBD(parent)
	local bg = CreateFrame("Frame", nil, parent)
		bg:SetFrameStrata("LOW")
		bg:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", 1, -1)
		bg:SetPoint("TOPLEFT", parent, "TOPLEFT", -1, 1)
		bg:SetBackdrop({bgFile = [[Interface\AddOns\oUF_Real\media\plain]], edgeFile = [[Interface\AddOns\oUF_Real\media\plain]], edgeSize = 1, insets = {top = 0, bottom = 0, left = 0, right = 0}})
		bg:SetBackdropColor(0, 0, 0, db.overlay.bar.opacity.background)
		bg:SetBackdropBorderColor(0, 0, 0, db.overlay.bar.opacity.surround)
	return bg
end

-- Readable Numbers
function UnitFrames:ReadableNumber(num, places)
    local ret
    local placeValue = ("%%.%df"):format(places or 0)
    if not num then
        return 0
    elseif num >= 10000000 then
        ret = tostring(floor(num / 1000000)) .. "m" -- million (no decimal)
	elseif num >= 1000000 then
        ret = placeValue:format(num / 1000000) .. "m" -- million
	elseif num >= 200000 then
        places = 0
		ret = tostring(floor(num / 1000)) .. "k" -- thousand (no decimal)
    elseif num >= 1000 then
        ret = placeValue:format(num / 1000) .. "k" -- thousand
    else
        ret = num -- hundreds
    end
    return ret
end

-- Abbreviated Name
local NameLengths = {
	[1] = {
		[TARGET_ID] = 20,
		[FOCUS_ID] = 12,
		[FOCUSTARGET_ID] = 12,
		[TARGETTARGET_ID] = 12,
		[MAINTANK_ID] = 12,
		[BOSS_ID] = 12,
		[PET_ID] = 14,
	},
	[2] = {
		[TARGET_ID] = 18,
		[FOCUS_ID] = 12,
		[FOCUSTARGET_ID] = 12,
		[TARGETTARGET_ID] = 12,
		[MAINTANK_ID] = 12,
		[BOSS_ID] = 12,
		[PET_ID] = 14,
	},
}
function UnitFrames:AbrvName(name, ...)
	if not name then return "" end
	local UnitID = ... or BOSS_ID
	local maxNameLength = NameLengths[db.layout][UnitID] or 12
	
	local newName = (strlen(name) > maxNameLength) and gsub(name, "%s?(.[\128-\191]*)%S+%s", "%1.") or name
	if strlen(newName) > maxNameLength then
		newName = strsub(newName, 1, maxNameLength - 1)..".."
	end
	
	return newName
end

-- Power Colors
function UnitFrames:SetPowerColors()
	self.PowerColors = {}
	for pToken, color in pairs(db.overlay.colors.power) do
		if color[1] then
			self.PowerColors[pToken] = color
			oUF.colors.power[pToken] = color
		end
	end
	self.PowerColors["POWER_TYPE_PYRITE"] = { 0, 0.79215693473816, 1 }
	self.PowerColors["POWER_TYPE_STEAM"] = { 0.94901967048645, 0.94901967048645, 0.94901967048645 }
	self.PowerColors["POWER_TYPE_HEAT"] = { 1, 0.490019610742107, 0 }
	self.PowerColors["POWER_TYPE_BLOOD_POWER"] = { 0.73725494556129, 0, 1 }
	self.PowerColors["POWER_TYPE_OOZE"] = { 0.75686281919479, 1, 0 }
end

function UnitFrames:SetUpdateSpeed()
	db.misc.powerupdatespeed = {
		["default"] = 	1/10,
		["ENERGY"] = 	1/20,
	}
end

----------------------------
------ Options Window ------
----------------------------

-- Add a small panel to the Interface - Addons options
local intoptions = nil
local function GetIntOptions()
	if not intoptions then
		intoptions = {
			name = "oUF_Real",
			handler = oUF_Real,
			type = "group",
			args = {
				note = {
					type = "description",
					name = "You can also access the oUF_Real Options by typing: /real",
					fontSize = "medium",
					order = 10,
				},
				openoptions = {
					type = "execute",
					name = "Open oUF_Real Options",
					func = function() 
						UnitFrames:OpenOptions()
					end,
					order = 20,
				},
			},
		}
	end
	return intoptions
end

function UnitFrames:CloseOptions()
	LibStub("AceConfigDialog-3.0"):Close("oUF_Real")
end

function UnitFrames:OpenOptions(...)
	if not options then self:SetUpOptions() end
	LibStub("AceConfigDialog-3.0"):Open("oUF_Real")
end

function UnitFrames:ConfigRefresh()
	db = self.db.profile
end

function UnitFrames:SetUpInitialOptions()
	-- Create Interface - Addons panel
	LibStub("AceConfig-3.0"):RegisterOptionsTable("oUF_Real-Int", GetIntOptions)
	self.optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("oUF_Real-Int", "oUF_Real")
	
	db = self.db.profile
end

function UnitFrames:SetUpOptions()
	db = self.db.profile
	
	-- Fill out Options table
	GetOptions()
	
	options.args.profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db)
	options.args.profiles.order = -1
	
	-- Create RealUI Options window
	LibStub("AceConfig-3.0"):RegisterOptionsTable("oUF_Real", options)
	LibStub("AceConfigDialog-3.0"):SetDefaultSize("oUF_Real", 760, 600)
end

----------------------------
------ Initialization ------
----------------------------
function UnitFrames:OnInitialize()
	local defaults = {
		profile = {
			layout = 1,
			misc = {
				focusclick = true,
				focuskey = "shift",
				steppoints = {
					["default"] = 	{0.35, 0.25},
					["HUNTER"] = 	{0.35, 0.2},
					["PALADIN"] = 	{0.35, 0.2},
					["WARLOCK"] = 	{0.35, 0.2},
					["WARRIOR"] = 	{0.35, 0.2},
				},
				powerupdatespeed = {
					["default"] = 	1/10,
					["ENERGY"] = 	1/20,
				},
			},
			units = {
				arena = false,
				tank = false,
			},
			boss = {
				gap = 1,
				buffCount = 3,
				debuffCount = 5,
				showPlayerAuras = true,
				showNPCAuras = true,
				reverseHealth = true,
			},
			pet = {
				showName = true,
				hideOOC = false,
				reverseHealth = true,
				castBarColor = {0.5, 1, 0},
			},
			petFrameClasses = {
				["DEATHKNIGHT"] = true,
				["HUNTER"] = true,
				["MAGE"] = true,
				["WARLOCK"] = true,
			},
			positions = {
				[1] = {
					player = 		{ x = -287,	y = -38},
					pet = 			{ x = 11, 	y = 0},		-- Anchored to Player
					pet2 =			{ x = 0,	y = -164},
					focus = 		{ x = 0,	y = -51},	-- Anchored to Player
					focustarget = 	{ x = 0,	y = -10},	-- Anchored to Focus
					target = 		{ x = 287,	y = -38},
					targettarget = 	{ x = 0,	y = -51},	-- Anchored to Target
					boss =			{ x = -108,	y = 194},
				},
				[2] = {
					player = 		{ x = -307,	y = -38},
					pet = 			{ x = 11, 	y = 0},		-- Anchored to Player
					pet2 =			{ x = 0,	y = -164},
					focus = 		{ x = 0,	y = -51},	-- Anchored to Player
					focustarget = 	{ x = 0,	y = -10},	-- Anchored to Focus
					target = 		{ x = 307,	y = -38},
					targettarget = 	{ x = 0,	y = -51},	-- Anchored to Target
					boss =			{ x = -108,	y = 194},
				},
			},
			overlay = {
				font = {
					pixel1 = {[[Interface\AddOns\oUF_Real\media\pixel_lr_small.ttf]], 8, "OUTLINEMONOCHROME"},
					pixeltiny = {[[Interface\AddOns\oUF_Real\media\pixel_lr_small.ttf]], 8, "OUTLINEMONOCHROME"},
				},
				bar = {
					opacity = {
						surround = 		1,				-- Border of objects
						background = 	0.7,			-- Background of unit frame
						status = 		0.8,			-- Background of objects (arrow, end box, etc)
						bar = 			{0.0, 0.8},		-- Health/Power gradient {start, end}
						bar2 = 			{0.4, 0.9},		-- Pet/Vehicle Health/Power gradient {start, end}
						absorb = 		0.25,			-- Absorb Bar
						steps = 		0.7,			-- Tiny step indicator
					},
					colors = {
						byhostility = true,
						byclass = true,
					},
				},
				arrow = {
					opacity = {
						surround = 		1,
						background = 	0.8,
					},
					colors = {
						[1] = {1, 1, 1},
						[2] = {1, 1, 0},
						[3] = {1, 0, 0},
						[4] = {1, 0.5, 0},
					},
				},
				colors = {
					health = {
						normal = 	{0.70, 0.10, 0.10},
						hostile = 	{0.70, 0.10, 0.10},
						neutral = 	{0.75, 0.75, 0.00},
						friendly = 	{0.10, 0.70, 0.25},
					},
					power = {
						["MANA"] = 			{0.00, 0.45, 0.80},
						["RAGE"] = 			{0.85, 0.15, 0.15},
						["FOCUS"] = 		{1.00, 0.50, 0.25},
						["ENERGY"] = 		{0.95, 0.85, 0.10},
						["CHI"] =		 	{0.71, 1.00, 0.92},
						["RUNES"] = 		{0.50, 0.50, 0.50},
						["RUNIC_POWER"] = 	{0.00, 0.82, 1.00},
						["SOUL_SHARDS"] = 	{0.50, 0.32, 0.55},
						["HOLY_POWER"] = 	{0.95, 0.90, 0.60},
						["AMMOSLOT"] = 		{0.80, 0.60, 0.00},
						["FUEL"] = 			{0.00, 0.55, 0.50},
						["ALTERNATE"] =		{0.00, 0.85, 0.85},
					},
					status = {
						damage = 		{1, 0, 0},
						incomingheal = 	{1, 1, 0},
						heal = 			{0, 1, 0},
						resting = 		{0, 1, 0},
						combat = 		{1, 0, 0},
						afk = 			{1, 1, 0},
						offline = 		{0.6, 0.6, 0.6},
						leader = 		{0, 1, 1},
						tapped = 		{0.4, 0.4, 0.4},
						pvpenemy = 		{0.2, 0, 0},
						pvpfriendly = 	{0, 0.2, 0},
						dead = 			{0.2, 0.2, 0.2},
					},
				},
			},
			combatFader = {
				opacity = {
					incombat =		1,
					target =		0.8,
					hurt =			0.8,
					outofcombat =	0.3
				},
			},
		},
	}
	self.db = LibStub("AceDB-3.0"):New("oUF_RealDB", defaults, "oUF_Real")
	db = self.db.profile
	db.overlay.font.pixel1 = fonts[db.layout]

	self.class = select(2, UnitClass("player"))
	self.petFrameClass = db.petFrameClasses[self.class]

	-- Profile change
	self.db.RegisterCallback(self, "OnProfileChanged", "Refresh")
	self.db.RegisterCallback(self, "OnProfileCopied", "Refresh")
	self.db.RegisterCallback(self, "OnProfileReset", "Refresh")
	
	-- Initial Options setup
	self:SetUpInitialOptions()
	
	-- Chat Commands
	self:RegisterChatCommand("real", function() UnitFrames:OpenOptions() end)
	self:RegisterChatCommand("rl", function() ReloadUI() end)
end

function UnitFrames:OnEnable()
	self:SetUpdateSpeed()
	self:SetPowerColors()
	self.colorStrings = {
		health = self:ColorTableToStr(db.overlay.colors.health.normal),
		mana = self:ColorTableToStr(db.overlay.colors.power["MANA"]),
	}
	
	self:InitializeLayout()
end

function UnitFrames:Refresh()	
	db = self.db.profile
	self:ReloadUIDialog()
end