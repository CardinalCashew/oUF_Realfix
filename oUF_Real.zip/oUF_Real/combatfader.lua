local name, ns = ...

local UnitFrames = LibStub("AceAddon-3.0"):GetAddon("oUF_Real")
local CombatFader = UnitFrames:NewModule("CombatFader", "AceEvent-3.0", "AceBucket-3.0")
UnitFrames.CombatFader = CombatFader

local FirstLog = true

local frames = {
	["oUF_RealPlayer_Overlay"] = true,
	["oUF_RealTarget_Overlay"] = true,
	["oUF_RealFocus_Overlay"] = true,
	["oUF_RealFocusTarget_Overlay"] = true,
	["oUF_RealTargetTarget_Overlay"] = true,
	["oUF_RealPet_Overlay"] = true,
}

-- Power 'Full' check
local PowerCheck = {
	MANA = function()
		return UnitPower("player") < UnitPowerMax("player")
	end,
	RAGE = function()
		return UnitPower("player") > 0
	end,
	ENERGY = function()
		return UnitPower("player") < UnitPowerMax("player")
	end,
	FOCUS = function()
		return UnitPower('player') < UnitPowerMax('player')
	end,
	RUNIC_POWER = function()
		return UnitPower("player") > 0
	end,
}

-- Fade frame
function CombatFader:FadeIt(Frame, NewOpacity)
	local CurrentOpacity = Frame:GetAlpha()
	if NewOpacity > CurrentOpacity then
		UIFrameFadeIn(Frame, 0.25, CurrentOpacity, NewOpacity)
	elseif NewOpacity < CurrentOpacity then
		UIFrameFadeOut(Frame, 0.25, CurrentOpacity, NewOpacity)
	end
end

-- Determine new opacity values for frames
function CombatFader:FadeFrames()
	if not UnitFrames.db then return end
	local NewOpacity = 1
	if self.Status == "INCOMBAT" then
		NewOpacity = UnitFrames.db.profile.combatFader.opacity.incombat
	elseif self.Status == "TARGET" then
		NewOpacity = UnitFrames.db.profile.combatFader.opacity.target
	elseif self.Status == "HURT" then
		NewOpacity = UnitFrames.db.profile.combatFader.opacity.hurt
	elseif self.Status == "OUTOFCOMBAT" then
		NewOpacity = UnitFrames.db.profile.combatFader.opacity.outofcombat
	end
	
	for k, v in pairs(frames) do
		if frames[k] then
			if _G[k] then self:FadeIt(_G[k], NewOpacity) end
		end
	end
end

-- Update current status
function CombatFader:UpdateStatus(forceUpdate)
	local OldStatus = self.Status
	if UnitAffectingCombat("player") then
		self.Status = "INCOMBAT"
	elseif UnitExists("target") then
		self.Status = "TARGET"
	elseif UnitHealth("player") < UnitHealthMax("player") then
		self.Status = "HURT"
	else
		local _, pToken = UnitPowerType("player")
		local func = PowerCheck[pToken]
		if func and func() then
			self.Status = "HURT"
		else
			self.Status = "OUTOFCOMBAT"
		end
	end
	if self.Status ~= OldStatus or forceUpdate then self:FadeFrames() end
end

function CombatFader:HurtEvent(units)
	if units and units.player then self:UpdateStatus() end
end

-- On combat state change
function CombatFader:UpdateCombatState(event)
	-- If in combat, then don't worry about health/power events
	if UnitAffectingCombat("player") and not FirstLog then
		self:UnregisterAllBuckets()
	else
		self:RegisterBucketEvent({"UNIT_HEALTH", "UnitPower", "UNIT_DISPLAYPOWER"}, 0.1, "HurtEvent")
		if event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_REGEN_ENABLED" then
			FirstLog = false
		end
	end
	self:UpdateStatus(true)
end

function CombatFader:UNIT_PET()
	self:UpdateStatus(true)
end

function CombatFader:PLAYER_TARGET_CHANGED()
	self:UpdateStatus()
end

function CombatFader:PLAYER_ENTERING_WORLD()
	self.Status = ""
	self:UpdateStatus(true)
end

function CombatFader:OnInitialize()
	self:RegisterEvent("PLAYER_ENTERING_WORLD")
	self:RegisterEvent("PLAYER_TARGET_CHANGED")
	self:RegisterEvent("UNIT_PET")
	self:RegisterEvent("PLAYER_REGEN_ENABLED", "UpdateCombatState")
	self:RegisterEvent("PLAYER_REGEN_DISABLED", "UpdateCombatState")
end